<div class="col-7 d-flex justify-content-center align-items-center p-0 m-0 vh-100 border">
    <div class="custom__container__auth ">
        <img src="/assets/img/logo.png" alt="" style="width : 421px ; height :435.03px;">
    </div>
</div>