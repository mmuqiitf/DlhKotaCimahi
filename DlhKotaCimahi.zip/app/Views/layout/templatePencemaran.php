<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>DLH KOTA CIMAHI</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <?= $this->include('/source/css') ?>

</head>

<body>



    <?= $this->include('/layout/sidebarPencemaran') ?>



    <?= $this->renderSection('content') ?>





    <?= $this->include('/source/js');  ?>

</body>



</html>