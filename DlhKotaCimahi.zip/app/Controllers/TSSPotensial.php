<?php

namespace App\Controllers;

class TSSPotensial extends BaseController
{
    public function index()
    {
        return view('/pages/TSSPotensial');
    }
}